<?php
session_start();
const DB_HOST='127.0.0.1'; const DB_NAME='horas_bangso_batak_v13'; const DB_USER='root'; const DB_PASS='';
function db(){static $p;if($p instanceof PDO)return $p;try{$p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}catch(PDOException $e){$root=new PDO('mysql:host='.DB_HOST.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$root->exec('CREATE DATABASE IF NOT EXISTS `'.DB_NAME.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');$p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}ensure_schema($p);ensure_v6_schema($p);ensure_marketplace_schema($p);return $p;}
function ensure_schema(PDO $p){static $done=false;if($done)return;$done=true;$sql=@file_get_contents(__DIR__.'/database/schema.sql');if($sql){$sql=preg_replace('/^CREATE DATABASE.*?;\s*/is','',$sql);$sql=preg_replace('/^USE\s+[^;]+;\s*/im','',$sql);foreach(preg_split('/;\s*(?:\r?\n|$)/',$sql) as $stmt){$stmt=trim($stmt);if($stmt){try{$p->exec($stmt);}catch(Throwable $e){}}}}$migrations=[['contact_branches','branch_type',"ALTER TABLE contact_branches ADD branch_type ENUM('DPP','DPD','DPC','Desa','Luar Negeri') DEFAULT 'DPC'"],['site_settings','facebook_url',"ALTER TABLE site_settings ADD facebook_url VARCHAR(500) NULL"],['site_settings','instagram_url',"ALTER TABLE site_settings ADD instagram_url VARCHAR(500) NULL"],['site_settings','youtube_url',"ALTER TABLE site_settings ADD youtube_url VARCHAR(500) NULL"],['site_settings','tiktok_url',"ALTER TABLE site_settings ADD tiktok_url VARCHAR(500) NULL"],['site_settings','whatsapp_url',"ALTER TABLE site_settings ADD whatsapp_url VARCHAR(500) NULL"],['site_settings','phone_icon','ALTER TABLE site_settings ADD phone_icon VARCHAR(255) NULL'],['site_settings','whatsapp_icon','ALTER TABLE site_settings ADD whatsapp_icon VARCHAR(255) NULL'],['site_settings','email_icon','ALTER TABLE site_settings ADD email_icon VARCHAR(255) NULL'],['site_settings','instagram_icon','ALTER TABLE site_settings ADD instagram_icon VARCHAR(255) NULL'],['site_settings','facebook_icon','ALTER TABLE site_settings ADD facebook_icon VARCHAR(255) NULL'],['site_settings','youtube_icon','ALTER TABLE site_settings ADD youtube_icon VARCHAR(255) NULL'],['site_settings','tiktok_icon','ALTER TABLE site_settings ADD tiktok_icon VARCHAR(255) NULL'],['members','member_role',"ALTER TABLE members ADD member_role ENUM('anggota','pengurus') DEFAULT 'anggota'"],['members','term_start','ALTER TABLE members ADD term_start DATE NULL'],['members','term_end','ALTER TABLE members ADD term_end DATE NULL'],['news','link_url','ALTER TABLE news ADD link_url VARCHAR(500) NULL'],['site_settings','chairman_name','UPDATE site_settings SET chairman_name="Lamsiang Sitompul, S.H., M.H." WHERE id=1 AND (chairman_name IS NULL OR chairman_name="Ketua Umum")']];foreach($migrations as [$t,$c,$q]){if(str_starts_with(strtoupper(ltrim($q)),'UPDATE ')){try{$p->exec($q);}catch(Throwable $e){}}else{$cols=$p->query("SHOW COLUMNS FROM `$t`")->fetchAll(PDO::FETCH_COLUMN);if(!in_array($c,$cols,true))$p->exec($q);}}try{$p->exec("UPDATE contact_branches SET name='DPP Horas Bangso Batak',branch_type='DPP',address='Jl Persaudaraan, Sisingamangaraja, Kota Medan, Sumatera Utara',maps_url='https://www.google.com/maps/search/?api=1&query=Jl+Persaudaraan+Sisingamangaraja+Medan+Sumatera+Utara' WHERE id=1");$p->exec("UPDATE site_settings SET organization_address='Jl Persaudaraan, Sisingamangaraja, Kota Medan, Sumatera Utara' WHERE id=1 AND (organization_address IS NULL OR organization_address='')");}catch(Throwable $e){} }
function ensure_v6_schema(PDO $p){
  try{
    $p->exec("CREATE TABLE IF NOT EXISTS hero_slides(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,subtitle TEXT,eyebrow VARCHAR(120),image_url VARCHAR(500),button_text VARCHAR(120),button_url VARCHAR(500),sort_order INT DEFAULT 0,is_active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
    $n=(int)$p->query('SELECT COUNT(*) FROM hero_slides')->fetchColumn();
    if($n===0){$st=$p->prepare('INSERT INTO hero_slides(eyebrow,title,subtitle,image_url,button_text,button_url,sort_order,is_active) VALUES(?,?,?,?,?,?,?,1)');$slides=[['WARISAN BUDAYA BATAK','Horas Bangso Batak','Merawat adat, budaya, persaudaraan, dan martabat Bangso Batak dengan tata kelola organisasi yang modern.','https://batakkeren.com/wp-content/uploads/2024/01/Rumah_Bolon_Rumah_Adat_Suku_Batak_di_Sumatera_Utara-scaled.jpg','Bergabung Menjadi Anggota','register.php',1],['DANAU TOBA · TANAH BATAK','Tanah Leluhur, Rumah Bersama','Menghubungkan generasi Batak di tanah kelahiran maupun perantauan.','https://www.indonesia.travel/link/69ceddb5944b445b84498350ffc5c659.aspx','Verifikasi Anggota','member-check.php',2],['ULOS · WARISAN TAKBENDA','Ulos, Identitas dan Kehangatan','Merawat kain, simbol, dan nilai budaya Batak dari generasi ke generasi.','https://www.indonesia.travel/contentassets/63e9a97724d54382b1f8ef617b1dfddf/kain-tenun-ulos-khas-batak-3.jpg','Pelajari Budaya','index.php#tentang',3],['TORTOR · SENI DAN TRADISI','Gerak Budaya yang Hidup','Merayakan kebersamaan melalui seni, tortor, musik, dan tradisi Batak.','https://www.indonesia.travel/link/f2f92b5af11a4d0391ad13023d045521.aspx','Lihat Kegiatan','news.php',4]];foreach($slides as $x)$st->execute($x);}
  }catch(Throwable $e){}
}
function e($v){
    if (is_array($v) || is_object($v)) {
        $v = json_encode($v, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }
    return htmlspecialchars((string)($v??''), ENT_QUOTES, 'UTF-8');
}
function decode_nested_json($raw){
    $v=$raw;
    for($i=0;$i<8;$i++){
        if(!is_string($v)) break;
        $t=trim($v);
        if($t==='') return [];
        $d=json_decode($t,true);
        if(json_last_error()!==JSON_ERROR_NONE) break;
        $v=$d;
    }
    return $v;
}
function normalize_payment_methods($raw){
    $a=decode_nested_json($raw);
    if(is_array($a) && isset($a['name'])) $a=[$a];
    if(!is_array($a)) return [];
    $out=[];
    $walk=function($v)use(&$walk,&$out){
        $v=decode_nested_json($v);
        if(is_string($v)){ $v=trim($v); if($v!=='') $out[]=$v; return; }
        if(is_array($v)){
            if(isset($v['name'])||isset($v['label'])){ $n=trim((string)($v['name']??$v['label']??'')); if($n!=='')$out[]=$n; return; }
            foreach($v as $x)$walk($x);
        }
    };
    $walk($a);
    return array_values(array_unique($out));
}
function normalize_courier_methods($raw){
    $a=decode_nested_json($raw);
    if(is_array($a) && isset($a['name'])) $a=[$a];
    if(!is_array($a)) return [];
    $out=[];
    $walk=function($v)use(&$walk,&$out){
        $v=decode_nested_json($v);
        if(is_string($v)){ $v=trim($v); if($v!=='')$out[]=['name'=>$v,'base'=>0,'per_km'=>0]; return; }
        if(is_array($v)){
            if(isset($v['name'])||isset($v['label'])){
                $name=trim((string)($v['name']??$v['label']??''));
                if($name!=='')$out[]=['name'=>$name,'base'=>max(0,(float)($v['base']??$v['base_fee']??0)),'per_km'=>max(0,(float)($v['per_km']??$v['tariff_per_km']??0))];
                return;
            }
            foreach($v as $x)$walk($x);
        }
    };
    $walk($a);
    $uniq=[];foreach($out as $v)$uniq[$v['name']]=$v;return array_values($uniq);
}
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function check_csrf($v){if(!$v||!hash_equals($_SESSION['csrf']??'',$v))exit('Permintaan tidak valid.');}
function customer(){
    if(empty($_SESSION['customer_id'])){
        $_SESSION['customer_next']=$_SERVER['REQUEST_URI']??'marketplace.php';
        header('Location: customer_login.php'); exit;
    }
    try{
        $s=db()->prepare("SELECT id,name,email,phone FROM marketplace_customers WHERE id=? AND status='active' LIMIT 1");
        $s->execute([(int)$_SESSION['customer_id']]); $c=$s->fetch();
        if(!$c){unset($_SESSION['customer_id'],$_SESSION['customer_name'],$_SESSION['customer_email'],$_SESSION['customer_phone']);header('Location: customer_login.php');exit;}
        $_SESSION['customer_name']=$c['name'];$_SESSION['customer_email']=$c['email'];$_SESSION['customer_phone']=$c['phone'];
        return $c;
    }catch(Throwable $e){unset($_SESSION['customer_id']);header('Location: customer_login.php');exit;}
}
function customer_id(){return (int)($_SESSION['customer_id']??0);}
function admin(){
    if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}
    try {
        $s=db()->prepare('SELECT id,name FROM admins WHERE id=? LIMIT 1');
        $s->execute([(int)$_SESSION['admin_id']]);
        $a=$s->fetch();
        if(!$a){
            unset($_SESSION['admin_id'],$_SESSION['admin_name']);
            header('Location: login.php?session=expired');
            exit;
        }
        $_SESSION['admin_name']=$a['name'];
    } catch(Throwable $e) {
        unset($_SESSION['admin_id'],$_SESSION['admin_name']);
        header('Location: login.php?session=expired');
        exit;
    }
}
function strong_password($p){return strlen($p)>=12 && preg_match('/[A-Z]/',$p) && preg_match('/[a-z]/',$p) && preg_match('/\d/',$p) && preg_match('/[^A-Za-z0-9]/',$p);}
function valid_media_url($url){if(!$url)return ''; $u=filter_var(trim($url),FILTER_VALIDATE_URL);if(!$u)return ''; $host=strtolower(parse_url($u,PHP_URL_HOST)??'');return (str_contains($host,'youtube.com')||str_contains($host,'youtu.be')||str_contains($host,'vimeo.com'))?$u:'';}
function upload_public_image($f,$prefix='img'){if(($f['error']??9)!==0)return '';if($f['size']>5*1024*1024)throw new Exception('Gambar maksimal 5 MB.');$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];if(!isset($map[$mime]))throw new Exception('Format gambar harus JPG, PNG, atau WEBP.');$dir=__DIR__.'/storage/media';if(!is_dir($dir))mkdir($dir,0755,true);$n=$prefix.'_'.bin2hex(random_bytes(8)).'.'.$map[$mime];if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$n))throw new Exception('Gagal menyimpan gambar.');return 'storage/media/'.$n;}

function upload_public_video($f,$prefix='video'){
    if(($f['error']??9)!==UPLOAD_ERR_OK) return '';
    if(($f['size']??0)>50*1024*1024) throw new Exception('Video maksimal 50 MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $map=['video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov'];
    if(!isset($map[$mime])) throw new Exception('Video harus MP4, WEBM, atau MOV.');
    $dir=__DIR__.'/storage/media';if(!is_dir($dir))mkdir($dir,0755,true);
    $n=$prefix.'_'.bin2hex(random_bytes(8)).'.'.$map[$mime];
    if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$n)) throw new Exception('Gagal menyimpan video.');
    return 'storage/media/'.$n;
}

function upload_private_member_file($f,$prefix='file',$max=5*1024*1024,$photo=false){if(($f['error']??9)!==UPLOAD_ERR_OK)throw new Exception('Upload file gagal.');if(($f['size']??0)>$max)throw new Exception('File terlalu besar.');$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$map=['image/jpeg'=>'jpg','image/png'=>'png','application/pdf'=>'pdf'];if(!isset($map[$mime]))throw new Exception('File harus JPG, PNG, atau PDF.');if($photo){$d=@getimagesize($f['tmp_name']);if(!$d||$d[1]<=0||abs(($d[0]/$d[1])-0.75)>.2)throw new Exception('Foto wajah harus portrait/3x4.');if(!in_array($mime,['image/jpeg','image/png'],true))throw new Exception('Foto wajah harus JPG atau PNG.');}$dir=__DIR__.'/storage/private';if(!is_dir($dir))mkdir($dir,0755,true);$n=$prefix.'_'.bin2hex(random_bytes(10)).'.'.$map[$mime];if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$n))throw new Exception('Gagal menyimpan file.');return $n;}

function upload_contact_icon($f,$prefix='contact_icon'){if(($f['error']??9)!==0)return '';if(($f['size']??0)>2*1024*1024)throw new Exception('Ikon maksimal 2 MB.');$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/svg+xml'=>'svg'];if(!isset($map[$mime]))throw new Exception('Ikon harus JPG, PNG, WEBP, atau SVG.');$dir=__DIR__.'/storage/contact-icons';if(!is_dir($dir))mkdir($dir,0755,true);$n=$prefix.'_'.bin2hex(random_bytes(8)).'.'.$map[$mime];if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$n))throw new Exception('Gagal menyimpan ikon.');return 'storage/contact-icons/'.$n;}
function replace_upload_field($f,$current,$prefix){if(($f['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return $current;return upload_public_image($f,$prefix);}

function member_status_label($s){return $s==='approved'?'Aktif':($s==='pending'?'Menunggu Verifikasi':'Tidak Aktif');}
function member_role_label($r){return $r==='pengurus'?'Pengurus':'Anggota';}

function require_member_sos(){if(empty($_SESSION['sos_member_id'])){header('Location: sos.php');exit;} $p=db();$s=$p->prepare("SELECT * FROM members WHERE id=? AND status='approved'");$s->execute([(int)$_SESSION['sos_member_id']]);$m=$s->fetch();if(!$m){unset($_SESSION['sos_member_id']);header('Location: sos.php');exit;}return $m;}
function hbb_base_url(){
    $script=str_replace('\\','/',$_SERVER['SCRIPT_NAME']??'/index.php');
    $dir=trim(str_replace('\\','/',dirname($script)),'/');
    $parts=$dir===''?[]:explode('/',$dir);
    if($parts && strtolower((string)end($parts))==='admin') array_pop($parts);
    return $parts?'/'.implode('/',$parts):'';
}
function media_url($path){
    $path=trim((string)$path); if($path==='') return '';
    if(preg_match('~^https?://~i',$path)) return $path;
    return hbb_base_url().'/media.php?f='.rawurlencode(ltrim(str_replace('\\','/',$path),'/'));
}
function media_exists($path){
    if(!$path || preg_match('~^https?://~i',$path)) return true;
    $path=ltrim(str_replace('\\','/',$path),'/');
    $candidates=[__DIR__.'/'.$path];
    if(!str_starts_with($path,'storage/media/')) $candidates[]=__DIR__.'/storage/media/'.basename($path);
    foreach($candidates as $candidate){if(is_file($candidate)) return true;}
    return false;
}
function code128_svg($text){$patterns=['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'];$vals=[];for($i=0;$i<strlen($text);$i++){$o=ord($text[$i]);if($o<32||$o>126)return ''; $vals[]=($o-32);} $start=104;$checksum=$start;foreach($vals as $i=>$v)$checksum+=($i+1)*$v;$vals[]=$checksum%103;$vals[]=$start; $x=8;$svg='<svg xmlns="http://www.w3.org/2000/svg" width="'.(($text?count($vals):1)*11+16).'" height="58" viewBox="0 0 '.(($text?count($vals):1)*11+16).' 58" role="img" aria-label="Barcode '.e($text).'" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="white"/>';foreach($vals as $v){$pat=$patterns[$v];$black=true;for($j=0;$j<strlen($pat);$j++){$w=(int)$pat[$j];if($black)$svg.='<rect x="'.$x.'" y="5" width="'.$w.'" height="38" fill="#111"/>'; $x+=$w;$black=!$black;}}$svg.='<text x="50%" y="54" text-anchor="middle" font-family="Arial" font-size="8" fill="#111">'.e($text).'</text></svg>';return $svg;}


function ensure_marketplace_schema(PDO $p){
    static $done=false;if($done)return;$done=true;
    $safe=function($sql)use($p){try{$p->exec($sql);return true;}catch(Throwable $e){return false;}};
    $safe("CREATE TABLE IF NOT EXISTS marketplace_customers(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,email VARCHAR(190) NOT NULL UNIQUE,phone VARCHAR(40) NOT NULL,password_hash VARCHAR(255) NOT NULL,status ENUM('active','blocked') DEFAULT 'active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(phone))");
    $safe("CREATE TABLE IF NOT EXISTS product_media(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,product_id BIGINT UNSIGNED NOT NULL,media_type ENUM('image','video') NOT NULL,file_path VARCHAR(255) NOT NULL,sort_order INT DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(product_id),INDEX(media_type))");
    $safe("CREATE TABLE IF NOT EXISTS marketplace_chats(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,customer_id BIGINT UNSIGNED NULL,product_id BIGINT UNSIGNED NULL,order_code VARCHAR(40) NULL,buyer_name VARCHAR(150) NOT NULL,buyer_phone VARCHAR(40) NOT NULL,sender ENUM('buyer','seller') NOT NULL,message TEXT NOT NULL,is_read TINYINT(1) DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(customer_id),INDEX(product_id),INDEX(order_code),INDEX(created_at))");
    $safe("CREATE TABLE IF NOT EXISTS marketplace_orders(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,customer_id BIGINT UNSIGNED NULL,order_code VARCHAR(40) UNIQUE NOT NULL,product_id BIGINT UNSIGNED NOT NULL,product_name VARCHAR(160) NOT NULL,unit_price DECIMAL(14,2) NOT NULL,quantity INT NOT NULL,subtotal DECIMAL(14,2) NOT NULL,customer_name VARCHAR(150) NOT NULL,phone VARCHAR(40) NOT NULL,address TEXT NOT NULL,buyer_lat DECIMAL(10,7) NULL,buyer_lng DECIMAL(10,7) NULL,distance_km DECIMAL(10,2) NULL,payment_type VARCHAR(30) NULL,payment_method VARCHAR(80) NOT NULL,courier VARCHAR(80) NOT NULL,courier_fee DECIMAL(14,2) DEFAULT 0,total DECIMAL(14,2) NOT NULL,payment_status VARCHAR(30) DEFAULT 'pending',tracking_number VARCHAR(100) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(customer_id),INDEX(order_code),INDEX(payment_status))");
    $safe("CREATE TABLE IF NOT EXISTS marketplace_tracking(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,order_id BIGINT UNSIGNED NOT NULL,status_label VARCHAR(100) NOT NULL,note TEXT NULL,lat DECIMAL(10,7) NULL,lng DECIMAL(10,7) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(order_id),INDEX(created_at))");
    $cols=function($table)use($p){try{return $p->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){return [];}};
    $adds=['seller_address'=>'ALTER TABLE products ADD seller_address TEXT NULL','seller_lat'=>'ALTER TABLE products ADD seller_lat DECIMAL(10,7) NULL','seller_lng'=>'ALTER TABLE products ADD seller_lng DECIMAL(10,7) NULL','payment_methods'=>'ALTER TABLE products ADD payment_methods TEXT NULL','courier_methods'=>'ALTER TABLE products ADD courier_methods TEXT NULL','video_path'=>'ALTER TABLE products ADD video_path VARCHAR(255) NULL','size_info'=>'ALTER TABLE products ADD size_info VARCHAR(180) NULL'];
    foreach($adds as $c=>$q)if(!in_array($c,$cols('products'),true))$safe($q);
    $orderAdds=['customer_id'=>'ALTER TABLE marketplace_orders ADD customer_id BIGINT UNSIGNED NULL AFTER id','buyer_lat'=>'ALTER TABLE marketplace_orders ADD buyer_lat DECIMAL(10,7) NULL','buyer_lng'=>'ALTER TABLE marketplace_orders ADD buyer_lng DECIMAL(10,7) NULL','distance_km'=>'ALTER TABLE marketplace_orders ADD distance_km DECIMAL(10,2) NULL','payment_type'=>'ALTER TABLE marketplace_orders ADD payment_type VARCHAR(30) NULL AFTER distance_km','tracking_number'=>'ALTER TABLE marketplace_orders ADD tracking_number VARCHAR(100) NULL'];
    foreach($orderAdds as $c=>$q)if(!in_array($c,$cols('marketplace_orders'),true))$safe($q);
    // Legacy versions created payment_status as a restrictive ENUM. Marketplace workflow now needs the full lifecycle.
    try{$otype=$p->query("SHOW COLUMNS FROM marketplace_orders LIKE 'payment_status'")->fetch();if($otype && stripos((string)($otype['Type']??''),'enum')===0)$p->exec("ALTER TABLE marketplace_orders MODIFY payment_status VARCHAR(30) NOT NULL DEFAULT 'pending'");}catch(Throwable $e){}
    if(!in_array('customer_id',$cols('marketplace_chats'),true))$safe("ALTER TABLE marketplace_chats ADD customer_id BIGINT UNSIGNED NULL AFTER id");
    try{$rows=$p->query("SELECT id,image_path,video_path FROM products WHERE (image_path IS NOT NULL AND image_path<>'') OR (video_path IS NOT NULL AND video_path<>'')")->fetchAll();$chk=$p->prepare('SELECT id FROM product_media WHERE product_id=? AND media_type=? AND file_path=? LIMIT 1');$ins=$p->prepare('INSERT INTO product_media(product_id,media_type,file_path,sort_order) VALUES(?,?,?,?)');foreach($rows as $r){foreach([['image',$r['image_path'],0],['video',$r['video_path'],999]] as $m){if(empty($m[1]))continue;$chk->execute([(int)$r['id'],$m[0],$m[1]]);if(!$chk->fetch())$ins->execute([(int)$r['id'],$m[0],$m[1],$m[2]]);}}}catch(Throwable $e){}
}

