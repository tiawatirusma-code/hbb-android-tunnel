DROP DATABASE IF EXISTS horas_bangso_batak_v13;
CREATE DATABASE horas_bangso_batak_v13 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE horas_bangso_batak_v13;
