-- HBB Marketplace v12 safe migration
-- Does NOT delete or recreate existing data.
-- The application also performs these checks automatically from config.php.

CREATE TABLE IF NOT EXISTS marketplace_tracking (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  status_label VARCHAR(100) NOT NULL,
  note TEXT NULL,
  lat DECIMAL(10,7) NULL,
  lng DECIMAL(10,7) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX(order_id), INDEX(created_at)
);

-- If your MySQL supports ADD COLUMN IF NOT EXISTS, these can be run directly.
-- Otherwise the application performs SHOW COLUMNS checks and adds only missing columns.
-- marketplace_orders.payment_type VARCHAR(30) NULL
-- marketplace_orders.customer_id BIGINT UNSIGNED NULL
-- marketplace_orders.buyer_lat DECIMAL(10,7) NULL
-- marketplace_orders.buyer_lng DECIMAL(10,7) NULL
-- marketplace_orders.distance_km DECIMAL(10,2) NULL
-- marketplace_orders.tracking_number VARCHAR(100) NULL

-- Legacy payment_status ENUM must allow: pending, paid, processing, shipped, delivered, cancelled.
-- The application automatically changes it to VARCHAR(30) when needed.
