<?php require '../config.php';admin();$p=db();$msg='';if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf($_POST['csrf']??'');$id=(int)$_POST['id'];$status=in_array($_POST['status'],['new','acknowledged','resolved'],true)?$_POST['status']:'new';$p->prepare('UPDATE sos_alerts SET status=?,acknowledged_by=?,acknowledged_at=? WHERE id=?')->execute([$status,$status==='new'?null:$_SESSION['admin_id'],$status==='new'?null:date('Y-m-d H:i:s'),$id]);$msg='Status SOS diperbarui.';}$rows=$p->query("SELECT s.*,m.full_name,m.member_code,m.phone FROM sos_alerts s JOIN members m ON m.id=s.member_id ORDER BY s.id DESC LIMIT 100")->fetchAll();$new=(int)$p->query("SELECT COUNT(*) FROM sos_alerts WHERE status='new'")->fetchColumn();$latestId=(int)($p->query('SELECT COALESCE(MAX(id),0) FROM sos_alerts')->fetchColumn());?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="admin.css"><title>SOS Anggota</title><style>.alarm-panel{display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:16px;border:1px solid #e2c27b;background:#fff9e9;border-radius:12px;margin-bottom:18px}.alarm-panel button,.alarm-panel select{padding:11px 14px;font-weight:800}.alarm-state{font-weight:800}.alarm-help{width:100%;font-size:12px;color:#6b5d45;line-height:1.5}.alarm-meter{width:100%;height:8px;background:#eadfca;border-radius:99px;overflow:hidden}.alarm-meter i{display:block;height:100%;width:0;background:#9b1d29;transition:width .2s}.sos-new{animation:sosblink 1s infinite}@keyframes sosblink{50%{background:#fff0f0}}</style></head><body><?php require '_nav.php';?><main><div class="pagehead"><div><div class="eyebrow">KESELAMATAN ANGGOTA</div><h1>SOS Darurat <span class="sos-badge" id="newBadge">+<?=$new?></span></h1><p>Aktifkan alarm sekali melalui tombol tes. Setelah itu SOS baru akan mencoba berbunyi otomatis selama halaman admin tetap terbuka.</p></div></div><?php if($msg):?><div class="notice"><?=e($msg)?></div><?php endif;?><section class="alarm-panel"><button type="button" id="testSound">🔊 Tes Bunyi Alarm</button><button type="button" id="armSound">🚨 Aktifkan Alarm Otomatis</button><select id="alarmType"><option value="siren">Sirene Darurat</option><option value="rapid">Alarm Cepat</option><option value="pulse">Pulsa Darurat</option></select><span class="alarm-state" id="alarmState">Alarm belum diaktifkan</span><div class="alarm-meter"><i id="alarmMeter"></i></div><div class="alarm-help">Jika tombol ditekan tetapi tetap tidak terdengar, periksa ikon speaker/tab browser, volume Windows, dan pastikan output suara Windows diarahkan ke earphone. File alarm lokal dan Web Audio akan dicoba bersamaan.</div></section><audio id="alarmAudio" preload="auto" src="../assets/sos-alarm.wav"></audio><section><div class="tablewrap"><table><tr><th>Waktu</th><th>Anggota</th><th>Lokasi</th><th>Akurasi</th><th>Status</th><th>Aksi</th></tr><?php foreach($rows as $r):?><tr class="<?=e($r['status'])?>" data-sos-id="<?=$r['id']?>"><td><?=e($r['created_at'])?></td><td><b><?=e($r['full_name'])?></b><small><?=e($r['member_code'])?> · <?=e($r['phone'])?></small></td><td><a target="_blank" rel="noopener" href="https://www.google.com/maps?q=<?=e($r['latitude'])?>,<?=e($r['longitude'])?>">Buka Titik GPS ↗</a><small><?=e($r['latitude'])?>, <?=e($r['longitude'])?></small></td><td><?=e($r['accuracy_m']??'—')?> m</td><td><span class="sos-tag <?=e($r['status'])?>"><?=strtoupper(e($r['status']))?></span></td><td><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="id" value="<?=$r['id']?>"><select name="status"><option value="new" <?=$r['status']==='new'?'selected':''?>>Baru</option><option value="acknowledged" <?=$r['status']==='acknowledged'?'selected':''?>>Ditangani</option><option value="resolved" <?=$r['status']==='resolved'?'selected':''?>>Selesai</option></select><button>Simpan</button></form></td></tr><?php endforeach;?></table><?php if(!$rows):?><div class="empty-admin">Belum ada SOS masuk.</div><?php endif;?></div></section></main><script>
let latestId=<?=$latestId?>, alarmOn=localStorage.getItem('hbb_sos_alarm')==='1',ctx=null,master=null,alarmTimer=null,alarmType=localStorage.getItem('hbb_alarm_type')||'siren',alarmBusy=false;
const type=document.getElementById('alarmType'),state=document.getElementById('alarmState'),test=document.getElementById('testSound'),arm=document.getElementById('armSound'),audio=document.getElementById('alarmAudio'),meter=document.getElementById('alarmMeter');
type.value=alarmType;
type.onchange=()=>{alarmType=type.value;localStorage.setItem('hbb_alarm_type',alarmType)};
function stateText(){state.textContent=alarmOn?'🚨 Alarm aktif — SOS baru akan berbunyi otomatis':'Alarm belum diaktifkan';arm.textContent=alarmOn?'🔕 Matikan Alarm Otomatis':'🚨 Aktifkan Alarm Otomatis';meter.style.width=alarmOn?'100%':'0%';}
stateText();
async function initAudio(){
 const C=window.AudioContext||window.webkitAudioContext;
 if(!C) throw new Error('Web Audio tidak didukung browser ini');
 if(!ctx) ctx=new C();
 if(ctx.state==='suspended') await ctx.resume();
 if(ctx.state!=='running') throw new Error('AudioContext belum running');
 if(!master){master=ctx.createGain();master.gain.value=0.95;master.connect(ctx.destination)}
 return ctx;
}
function tone(freq,dur,start,vol=.42){
 if(!ctx||ctx.state!=='running')return;
 const o=ctx.createOscillator(),g=ctx.createGain(),t=ctx.currentTime+start;
 o.type='sawtooth';o.frequency.setValueAtTime(freq,t);o.frequency.exponentialRampToValueAtTime(freq*1.35,t+dur*.42);o.frequency.exponentialRampToValueAtTime(Math.max(80,freq*.72),t+dur);
 g.gain.setValueAtTime(.001,t);g.gain.linearRampToValueAtTime(vol,t+.02);g.gain.setValueAtTime(vol,t+dur*.72);g.gain.exponentialRampToValueAtTime(.001,t+dur);
 o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+.05);
}
function webSiren(cycles=3){
 let b=0;
 for(let c=0;c<cycles;c++){
  if(alarmType==='rapid'){tone(1100,.16,b,.48);tone(620,.16,b+.18,.48);tone(1100,.16,b+.36,.48);tone(620,.16,b+.54,.48);b+=.74}
  else if(alarmType==='pulse'){tone(980,.48,b,.50);tone(980,.12,b+.60,.50);tone(980,.48,b+.82,.50);b+=1.48}
  else{tone(620,.40,b,.48);tone(1180,.40,b+.43,.48);tone(620,.40,b+.86,.48);tone(1180,.40,b+1.29,.48);b+=1.76}
 }
}
async function playLocalAlarm(seconds=5){
 audio.pause();audio.currentTime=0;audio.loop=false;audio.volume=1.0;
 try{audio.load();const pr=audio.play();if(pr&&pr.then)await pr;}catch(e){return false}
 clearTimeout(alarmTimer);alarmTimer=setTimeout(()=>{audio.pause();audio.currentTime=0;},seconds*1000);return true;
}
async function playAlarm(seconds=5){
 if(alarmBusy)return true;
 alarmBusy=true;meter.style.width='100%';
 let played=false;
 try{await initAudio();webSiren(Math.max(2,Math.ceil(seconds/1.76)));played=true}catch(e){}
 const local=await playLocalAlarm(seconds);played=played||local;
 if(!played){alarmBusy=false;throw new Error('Audio tidak dapat diputar')}
 clearTimeout(alarmTimer);alarmTimer=setTimeout(()=>{audio.pause();audio.currentTime=0;meter.style.width=alarmOn?'100%':'0%';alarmBusy=false;},seconds*1000);
 return true;
}
async function testAlarm(){
 try{
  await initAudio();
  alarmOn=true;localStorage.setItem('hbb_sos_alarm','1');stateText();
  await playAlarm(5);
 }catch(e){alert('Alarm belum dapat diputar. Pastikan volume Windows dan output earphone aktif, tab tidak mute, lalu klik Tes Bunyi Alarm sekali lagi.');}
}
async function toggleAlarm(){
 if(alarmOn){alarmOn=false;localStorage.setItem('hbb_sos_alarm','0');audio.pause();audio.currentTime=0;clearTimeout(alarmTimer);stateText();return}
 try{await initAudio();alarmOn=true;localStorage.setItem('hbb_sos_alarm','1');stateText();await playAlarm(3)}catch(e){alert('Browser belum mengaktifkan audio. Klik Tes Bunyi Alarm terlebih dahulu.')}}
test.onclick=testAlarm;arm.onclick=toggleAlarm;
async function announce(){
 document.title='🚨 SOS DARURAT · HBB';
 if(alarmOn){try{await playAlarm(10)}catch(e){}}
 if('Notification' in window&&Notification.permission==='granted')new Notification('🚨 SOS DARURAT HBB',{body:'SOS baru masuk. Segera buka titik GPS anggota.',tag:'hbb-sos-'+Date.now()});
 const badge=document.getElementById('newBadge');badge.textContent='🚨 SOS BARU';badge.style.background='#9b1d29';badge.style.color='#fff';
 setTimeout(()=>{document.title='SOS Darurat | HBB'},10000);
}
async function poll(){
 try{
  const r=await fetch('sos-count.php?full=1',{cache:'no-store'});const j=await r.json();
  if(j.latest_id>latestId){latestId=j.latest_id;await announce();}
  document.getElementById('newBadge').textContent='+'+j.new;
 }catch(e){}
}
setInterval(poll,2000);
if('Notification' in window&&Notification.permission==='default'){Notification.requestPermission().catch(()=>{})}
window.addEventListener('beforeunload',()=>{try{audio.pause()}catch(e){}});
</script></body></html>