<?php
function pdf_escape($s){$s=str_replace(['\\','(',')'],['\\\\','\\(','\\)'],(string)$s);return $s;}
function pdf_utf($s){$s=preg_replace('/[^\x20-\x7E]/',' ',$s);return $s;}
function make_card_pdf($member,$site,$rules,$photoPath,$barcodeText){
  $W=255; $H=158; $objs=[]; $offsets=[];
  $add=function($data)use(&$objs){$objs[]=$data;return count($objs);};
  $font=$add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  $fontB=$add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");
  $imgObj=null;
  if($photoPath && is_file($photoPath)){$info=@getimagesize($photoPath);$jpg=@file_get_contents($photoPath);if($info&&$jpg&&($info['mime']??'')==='image/jpeg')$imgObj=$add("<< /Type /XObject /Subtype /Image /Width {$info[0]} /Height {$info[1]} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ".strlen($jpg)." >>\nstream\n{$jpg}\nendstream");}
  $contentObjs=[];$pageObjs=[];
  $drawText=function(&$c,$x,$y,$size,$text,$fontName='/F1'){ $text=pdf_escape(pdf_utf($text));$c.="BT {$fontName} {$size} Tf 1 0 0 1 {$x} {$y} Tm ({$text}) Tj ET\n";};
  $barcode=function(&$c,$x,$y,$w,$h,$text){
    $patterns=['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','411131','211412','211214','211232','2331112'];
    $vals=[104];$sum=104;for($i=0;$i<strlen($text);$i++){ $v=ord($text[$i])-32;if($v<0||$v>94)$v=0;$vals[]=$v;$sum+=($i+1)*$v;}$vals[]=$sum%103;$vals[]=106;$total=0;foreach($vals as $v){foreach(str_split($patterns[$v]) as $n)$total+=(int)$n;}$scale=$w/$total;$xx=$x;$c.="q 1 1 1 rg {$x} {$y} {$w} {$h} re f Q\n";$black=true;foreach($vals as $v){foreach(str_split($patterns[$v]) as $n){$ww=(int)$n*$scale;if($black)$c.="{$xx} {$y} {$ww} {$h} re f\n";$xx+=$ww;$black=!$black;}}$c.="BT /F1 6 Tf 1 0 0 1 ".($x+$w/2-24)." ".($y-8)." Tm (".pdf_escape(pdf_utf($text)).") Tj ET\n";
  };
  // FRONT
  $c="q 0.06 0.14 0.19 rg 0 0 {$W} {$H} re f Q\nq 0.40 0.06 0.10 rg 0 0 255 40 re f Q\nq 0.12 0.31 0.43 rg 0 0 255 29 re f Q\nq 0.82 0.62 0.22 rg 0 148 255 10 re f Q\n";
  if($imgObj)$c.="q 1 0 0 1 18 52 cm /Im1 Do Q\n";
  $drawText($c,18,137,13,'HORAS BANGSO BATAK','/F2');$drawText($c,18,124,7,'KARTU TANDA ANGGOTA · DPP HBB');
  $c.="q 1 1 1 rg 18 65 46 52 re f Q\n";if($imgObj)$c.="q 46 0 0 52 18 65 cm /Im1 Do Q\n";
  $drawText($c,78,111,6,'ID ANGGOTA','/F2');$drawText($c,78,99,9,$member['member_code'],'/F2');$drawText($c,78,84,6,'NAMA','/F2');$name=mb_substr($member['full_name'],0,28);$drawText($c,78,72,8,$name,'/F2');$drawText($c,78,57,6,'JABATAN','/F2');$role=$member['member_role']==='pengurus'?'Pengurus':'Anggota';$drawText($c,78,46,8,$role,'/F2');$drawText($c,78,31,6,'MASA JABATAN','/F2');$term=($member['term_start']?:'—').' s/d '.($member['term_end']?:'—');$drawText($c,78,20,6.5,$term);$contentObjs[]=$add("<< /Length ".strlen($c)." >>\nstream\n{$c}endstream");
  // BACK: rules left, signature upper-right, barcode isolated at bottom-right
  $b="q 0.94 0.91 0.84 rg 0 0 {$W} {$H} re f Q\nq 0.72 0.12 0.16 rg 0 145 255 13 re f Q\n";$drawText($b,18,132,11,'HORAS BANGSO BATAK','/F2');$drawText($b,18,119,7,'TATA TERTIB KEANGGOTAAN','/F2');
  $ruleLines=preg_split('/\R/',pdf_utf($rules));$yy=106;foreach($ruleLines as $line){if($yy<68)break;$line=trim($line);if($line==='')continue;$drawText($b,18,$yy,5.8,'• '.mb_substr($line,0,55));$yy-=8;}
  // Signature block, deliberately separate from barcode
  $drawText($b,171,104,6,'TANDA NAMA DIGITAL','/F2');$drawText($b,171,91,8,'Lamsiang Sitompul','/F1');$drawText($b,171,79,6,'Lamsiang Sitompul, S.H., M.H.','/F2');$drawText($b,171,69,5.8,'Ketua Umum DPP HBB','/F1');$b.="q 0.45 0.30 0.15 RG 168 62 78 0.6 re S Q\n";
  // isolated barcode panel at bottom-right, no overlap with rules/signature
  $b.="q 1 1 1 rg 153 12 90 36 re f Q q 0.70 0.58 0.35 RG 153 12 90 36 re S Q\n";$barcode($b,158,21,80,20,$barcodeText);$drawText($b,174,8,5.2,'VERIFIKASI KEANGGOTAAN','/F2');
  $contentObjs[]=$add("<< /Length ".strlen($b)." >>\nstream\n{$b}endstream");
  $resFront="<< /Font << /F1 {$font} 0 R /F2 {$fontB} 0 R >>".($imgObj?" /XObject << /Im1 {$imgObj} 0 R >>":"")." >>";$resBack="<< /Font << /F1 {$font} 0 R /F2 {$fontB} 0 R >> >>";
  foreach([[$contentObjs[0],$resFront],[$contentObjs[1],$resBack]] as [$co,$res]){$page=$add("<< /Type /Page /MediaBox [0 0 {$W} {$H}] /Resources {$res} /Contents {$co} 0 R >>");$pageObjs[]=$page;}
  $pages=$add("<< /Type /Pages /Kids [{$pageObjs[0]} 0 R {$pageObjs[1]} 0 R] /Count 2 >>");$catalog=$add("<< /Type /Catalog /Pages {$pages} 0 R >>");$out="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets[0]=0;foreach($objs as $i=>$obj){$n=$i+1;$offsets[$n]=strlen($out);$out.="{$n} 0 obj\n{$obj}\nendobj\n";}$xref=strlen($out);$out.="xref\n0 ".(count($objs)+1)."\n0000000000 65535 f \n";for($i=1;$i<=count($objs);$i++)$out.=sprintf("%010d 00000 n \n",$offsets[$i]);$out.="trailer\n<< /Size ".(count($objs)+1)." /Root {$catalog} 0 R >>\nstartxref\n{$xref}\n%%EOF";return $out;
}
