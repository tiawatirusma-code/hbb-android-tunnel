<?php
require '../config.php';
admin();
$p=db();
$msg=''; $err='';

if (!empty($_SESSION['members_flash'])) {
  $f=$_SESSION['members_flash']; unset($_SESSION['members_flash']);
  if (($f['type']??'')==='ok') $msg=$f['text']; else $err=$f['text'];
}

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='verify_member') {
  try {
    $token=$_POST['csrf']??'';
    if (!$token || !hash_equals($_SESSION['csrf']??'', $token)) throw new RuntimeException('Sesi formulir sudah kedaluwarsa. Muat ulang halaman lalu coba lagi.');
    $id=(int)($_POST['id']??0);
    if($id<1) throw new RuntimeException('ID anggota tidak valid.');
    $st=$_POST['status']??'pending';
    if(!in_array($st,['pending','approved','rejected'],true)) throw new RuntimeException('Status verifikasi tidak valid.');
    $role=in_array($_POST['member_role']??'anggota',['anggota','pengurus'],true)?$_POST['member_role']:'anggota';
    if($st!=='approved') $role='anggota';
    $start=($role==='pengurus' && !empty($_POST['term_start']))?$_POST['term_start']:null;
    $end=($role==='pengurus' && !empty($_POST['term_end']))?$_POST['term_end']:null;
    if($role==='pengurus' && $start && $end && $end<$start) throw new RuntimeException('Masa jabatan selesai tidak boleh lebih awal dari tanggal mulai.');

    $adminId=(int)($_SESSION['admin_id']??0);
    $as=$p->prepare('SELECT id FROM admins WHERE id=? LIMIT 1');
    $as->execute([$adminId]);
    if(!$as->fetchColumn()) throw new RuntimeException('Sesi admin tidak lagi valid. Silakan login kembali.');

    $ms=$p->prepare('SELECT id,full_name,status FROM members WHERE id=? LIMIT 1');
    $ms->execute([$id]);
    $member=$ms->fetch();
    if(!$member) throw new RuntimeException('Data anggota tidak ditemukan.');

    if (!$p->inTransaction()) $p->beginTransaction();
    if($st==='approved') {
      $sql='UPDATE members SET status=?,member_role=?,term_start=?,term_end=?,admin_note=?,approved_by=?,approved_at=NOW(),updated_at=NOW() WHERE id=?';
      $args=[$st,$role,$start,$end,trim($_POST['note']??''),$adminId,$id];
    } else {
      $sql='UPDATE members SET status=?,member_role=?,term_start=?,term_end=?,admin_note=?,approved_by=NULL,approved_at=NULL,updated_at=NOW() WHERE id=?';
      $args=[$st,$role,$start,$end,trim($_POST['note']??''),$id];
    }
    $u=$p->prepare($sql);
    $u->execute($args);
    if ($u->rowCount() < 1 && $member['status'] !== $st) { throw new RuntimeException('Database tidak mengubah data anggota. Periksa struktur tabel members.'); }
    if ($p->inTransaction()) $p->commit();
    $_SESSION['members_flash']=['type'=>'ok','text'=>'Verifikasi untuk '.($member['full_name']??'anggota').' berhasil disimpan.'];
  } catch(Throwable $e) {
    if($p->inTransaction()) $p->rollBack();
    $_SESSION['members_flash']=['type'=>'err','text'=>'Gagal menyimpan verifikasi: '.$e->getMessage()];
    if(str_contains(strtolower($e->getMessage()),'sesi admin')) { unset($_SESSION['admin_id'],$_SESSION['admin_name']); header('Location: login.php?session=expired'); exit; }
  }
  $qs=!empty($_POST['return_q'])?'?q='.rawurlencode($_POST['return_q']):'';
  header('Location: members.php'.$qs); exit;
}

$q=trim($_GET['q']??'');
$sql='SELECT * FROM members'; $args=[];
if($q){$sql.=' WHERE full_name LIKE ? OR member_code LIKE ? OR nik LIKE ?';$x="%$q%";$args=[$x,$x,$x];}
$sql.=' ORDER BY id DESC';
$s=$p->prepare($sql);$s->execute($args);$rows=$s->fetchAll();
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="admin.css"><title>Daftar Anggota · HBB</title></head><body><?php require '_nav.php';?><main><div class="pagehead"><div><div class="eyebrow">DATABASE KEANGGOTAAN · DPP</div><h1>Daftar Anggota</h1><p>Verifikasi data lengkap, tetapkan status, dan angkat anggota aktif menjadi pengurus.</p></div></div><?php if($msg):?><div class="notice" role="status">✓ <?=e($msg)?></div><?php endif;?><?php if($err):?><div class="err" role="alert">⚠ <?=e($err)?></div><?php endif;?><form class="search" method="get"><div class="search-field"><input name="q" value="<?=e($q)?>" placeholder="Cari ID anggota, nama, atau NIK" autocomplete="off"><button type="submit">Cari</button></div><?php if($q):?><a class="buttonlink secondary-search" href="members.php">Reset</a><?php endif;?><a class="buttonlink export-search" href="export-members.php">Download Rekapitulasi</a></form><section><div class="tablewrap"><table><tr><th>ID</th><th>Data Lengkap</th><th>Dokumen</th><th>Verifikasi & Jabatan</th><th>Kartu</th><th>Aksi</th></tr><?php foreach($rows as $m):?><tr><td><b><?=e($m['member_code'])?></b><small><?=e($m['created_at'])?></small></td><td><b><?=e($m['full_name'])?></b><small>NIK: <?=e($m['nik'])?><br><?=e($m['birth_place'])?>, <?=e($m['birth_date'])?><br><?=e($m['gender'])?> · <?=e($m['religion'])?> · <?=e($m['blood_type'])?><br><?=nl2br(e($m['address']))?></small><small><?=e($m['phone'])?> · <?=e($m['education'])?> · <?=e($m['occupation'])?><br>Usulan: <?=e($m['proposed_position'])?></small></td><td><a href="file.php?id=<?=$m['id']?>&type=face" target="_blank">Foto</a> · <a href="file.php?id=<?=$m['id']?>&type=ktp" target="_blank">KTP</a></td><td><form method="post" action="members.php" class="verify" data-verify-form onsubmit="return verifySubmit(this);"><input type="hidden" name="action" value="verify_member"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="id" value="<?=$m['id']?>"><input type="hidden" name="return_q" value="<?=e($q)?>"><select name="status"><option value="pending" <?=$m['status']==='pending'?'selected':''?>>Menunggu Verifikasi</option><option value="approved" <?=$m['status']==='approved'?'selected':''?>>Aktif / Disetujui</option><option value="rejected" <?=$m['status']==='rejected'?'selected':''?>>Tidak Aktif / Ditolak</option></select><select name="member_role"><option value="anggota" <?=$m['member_role']==='anggota'?'selected':''?>>Anggota</option><option value="pengurus" <?=$m['member_role']==='pengurus'?'selected':''?>>Pengurus</option></select><div class="term-grid"><label>Mulai<input type="date" name="term_start" value="<?=e($m['term_start'])?>"></label><label>Selesai<input type="date" name="term_end" value="<?=e($m['term_end'])?>"></label></div><textarea name="note" placeholder="Catatan admin"><?=e($m['admin_note'])?></textarea><button type="submit" class="save-verify">Simpan Verifikasi</button></form></td><td><?php if($m['status']==='approved'):?><a class="cardlink" href="member-card.php?id=<?=$m['id']?>" target="_blank">Kartu Anggota ↗</a><?php else:?><small>Aktifkan anggota untuk membuat kartu.</small><?php endif;?></td><td><a class="edit-button" href="member-profile.php?id=<?=$m['id']?>">👤 Detail Profil</a><br><a class="edit-button" href="member-edit.php?id=<?=$m['id']?>">✏️ Edit</a></td></tr><?php endforeach;?></table></div></section></main><script>function verifySubmit(form){const b=form.querySelector('.save-verify');if(!b||form.dataset.saving==='1')return false;const status=form.querySelector('[name=status]').value;if(status==='approved'&&!confirm('Aktifkan dan simpan verifikasi anggota ini?'))return false;form.dataset.saving='1';b.disabled=true;b.classList.add('saving');b.textContent='Menyimpan…';return true;}document.querySelectorAll('[data-verify-form]').forEach(f=>{f.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.tagName!=='TEXTAREA'){e.preventDefault();}});});</script></body></html>