HBB WEBSITE PROFESSIONAL v8
===========================

Versi ini adalah penyempurnaan dari v7 untuk XAMPP/PHP + MySQL.

FITUR BARU v8
--------------
1. SOS Admin
   - Tombol "Tes Bunyi Alarm".
   - Tombol "Aktifkan Alarm Otomatis".
   - 3 pola alarm: Sirene Darurat, Alarm Cepat, Pulsa Darurat.
   - SOS baru dipantau otomatis setiap 2,5 detik.
   - Setelah audio browser diaktifkan melalui Tes Bunyi/Aktifkan Alarm, SOS baru memicu alarm otomatis.
   - Notifikasi browser digunakan bila izin tersedia.
   - Browser modern dapat memblokir autoplay audio sebelum interaksi pengguna; karena itu tombol Tes Bunyi adalah langkah aktivasi satu kali.

2. Edit Anggota
   - Admin dapat mengedit seluruh data anggota: nama, NIK, tempat/tanggal lahir, jenis kelamin, alamat, agama, darah, telepon, pendidikan, pekerjaan, usulan jabatan, status, peran, masa jabatan, catatan, foto, dan KTP.
   - ID anggota/member_code tidak berubah.
   - NIK tetap divalidasi agar tidak duplikat.

3. Edit Pengurus
   - Menu Daftar Pengurus mempunyai tombol "Edit Data Pengurus".
   - Pengurus diedit dari data anggota yang sama sehingga tidak membuat record pengurus ganda.

4. Kontak & Ikon
   - Admin dapat mengunggah ikon Telepon, WhatsApp, Email, Instagram, Facebook, YouTube, dan TikTok.
   - Setiap ikon dipasangkan dengan URL/nomor/email dan tampil sebagai tombol pada halaman Hubungi Kami serta footer.
   - Maksimum ikon 2 MB; JPG/PNG/WEBP/SVG.

5. Kartu Anggota
   - Tombol Cetak dan Download PDF tetap dipisahkan.
   - PDF mengambil foto anggota dari penyimpanan privat.
   - Barcode, tata tertib, dan blok nama Ketua Umum tetap dipisahkan agar tidak saling tumpang tindih.

INSTALASI
---------
1. Ekstrak folder hbb-fullstack ke C:\xampp\htdocs\
2. Pastikan Apache dan MySQL aktif.
3. Buka http://localhost/hbb-fullstack/
4. Jika database belum ada, aplikasi akan membuat database horas_bangso_batak_v13 dan tabel yang diperlukan secara otomatis.
5. Jangan menghapus database lama ketika memasang versi ini jika data anggota/admin ingin dipertahankan. Migrasi kolom baru berjalan otomatis.
6. Login admin: http://localhost/hbb-fullstack/admin/login.php
7. Jika belum ada admin, gunakan http://localhost/hbb-fullstack/admin/register.php

CATATAN KEAMANAN
----------------
- Data NIK/KTP tidak ditampilkan pada verifikasi publik.
- File anggota disimpan pada storage/private dan disajikan melalui endpoint admin.
- Gunakan HTTPS saat website dipasang online agar geolocation SOS dan login lebih aman.

MARKETPLACE MODERN UPDATE
- Marketplace publik terpisah dari Berita.
- Pencarian produk dan kategori marketplace.
- Sort terbaru, harga terendah, harga tertinggi.
- Admin dapat menambah/edit produk.
- Galeri hingga 15 foto per produk + video hingga 50 MB.
- Lokasi penjual menggunakan pencarian alamat atau GPS; koordinat disimpan otomatis.
- Checkout pembeli menggunakan pencarian alamat atau GPS; jarak pembeli-penjual dihitung otomatis.
- Pembayaran: QRIS, wallet, bank.
- Kurir: Gojek, Grab, J&T, JNE, SiCepat, AnterAja, Pos Indonesia, pickup.
- Ongkir: tarif dasar + jarak (km) x tarif per km.
- Database lama tidak perlu dihapus. Schema marketplace dimigrasikan otomatis.
