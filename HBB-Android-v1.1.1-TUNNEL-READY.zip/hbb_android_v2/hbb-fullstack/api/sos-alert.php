<?php require '../config.php';header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['ok'=>false,'message'=>'Metode tidak diizinkan.']);exit;}
if(empty($_SESSION['sos_member_id'])){http_response_code(401);echo json_encode(['ok'=>false,'message'=>'Sesi anggota tidak valid.']);exit;}
$raw=json_decode(file_get_contents('php://input'),true)?:[];if(!hash_equals($_SESSION['csrf']??'',(string)($raw['csrf']??''))){http_response_code(419);echo json_encode(['ok'=>false,'message'=>'Permintaan tidak valid.']);exit;}
$lat=filter_var($raw['latitude']??null,FILTER_VALIDATE_FLOAT);$lng=filter_var($raw['longitude']??null,FILTER_VALIDATE_FLOAT);$acc=filter_var($raw['accuracy']??null,FILTER_VALIDATE_FLOAT);
if($lat===false||$lng===false||$lat<-90||$lat>90||$lng<-180||$lng>180){http_response_code(422);echo json_encode(['ok'=>false,'message'=>'Koordinat lokasi tidak valid.']);exit;}
$p=db();$s=$p->prepare("SELECT full_name,member_code FROM members WHERE id=? AND status='approved'");$s->execute([(int)$_SESSION['sos_member_id']]);$m=$s->fetch();if(!$m){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Anggota tidak aktif.']);exit;}
$p->prepare('INSERT INTO sos_alerts(member_id,latitude,longitude,accuracy_m,note) VALUES(?,?,?,?,?)')->execute([(int)$_SESSION['sos_member_id'],$lat,$lng,$acc?:null,'SOS darurat dari '.$m['member_code']]);
$site=$p->query('SELECT contact_email FROM site_settings WHERE id=1')->fetchColumn();if($site && function_exists('mail')){@mail($site,'SOS Darurat HBB','SOS dari '.$m['full_name'].' ('.$m['member_code'].')\nLokasi: https://www.google.com/maps?q='.$lat.','.$lng);}
echo json_encode(['ok'=>true,'message'=>'SOS berhasil dikirim. Admin/operator menerima titik lokasi Anda.']);
