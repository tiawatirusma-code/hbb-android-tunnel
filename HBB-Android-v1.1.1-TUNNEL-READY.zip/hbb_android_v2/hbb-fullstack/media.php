<?php
// Dedicated public media endpoint. It intentionally does not expose the storage directory directly.
require 'config.php';
$f=trim((string)($_GET['f']??''));
$f=ltrim(str_replace('\\','/',$f),'/');
if($f==='' || !str_starts_with($f,'storage/media/')){http_response_code(404);exit;}
$base=realpath(__DIR__.'/storage/media');
$file=realpath(__DIR__.'/'.$f);
if(!$base || !$file || ($file!==$base && !str_starts_with($file,$base.DIRECTORY_SEPARATOR)) || !is_file($file)){http_response_code(404);exit;}
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($file) ?: 'application/octet-stream';
$allowed=['image/jpeg','image/png','image/webp','video/mp4','video/webm','video/quicktime'];
if(!in_array($mime,$allowed,true)){http_response_code(403);exit;}
header('Content-Type: '.$mime);
header('Content-Length: '.(string)filesize($file));
header('Cache-Control: public, max-age=86400');
header('X-Content-Type-Options: nosniff');
header('Content-Disposition: inline; filename="'.rawurlencode(basename($file)).'"');
readfile($file);
exit;
