HBB HORAS BANGSO BATAK - ANDROID v1.1.0 / WEBSITE v17
====================================================

VERSI INI MENDUKUNG 3 POLA KONEKSI:
1) Jaringan lokal/hotspot: HP dan laptop berada pada jaringan yang sama.
2) VPN pribadi: HP dan server/laptop terhubung ke VPN yang sama (contoh Tailscale/ZeroTier). Tidak harus hotspot yang sama.
3) Internet publik: API/website HBB dipasang pada hosting/VPS/domain HTTPS. HP boleh memakai Wi-Fi, hotspot berbeda, atau data seluler apa pun.

SEMUA POLA TETAP MENGGUNAKAN SATU DATABASE PUSAT horas_bangso_batak.

CARA TERBAIK UNTUK PRODUKSI:
- Pasang website + API HBB di VPS/hosting dengan HTTPS.
- Android cukup diarahkan ke https://domain-hbb-anda/ melalui menu Pengaturan Koneksi Server.
- Jangan membuka port MySQL ke internet. Hanya HTTP/HTTPS API yang boleh diakses.

UNTUK PENGUJIAN TANPA DOMAIN:
- Hotspot/Wi-Fi sama: http://IP-LAPTOP/hbb-fullstack/
- VPN Tailscale/ZeroTier: http://IP-VPN-SERVER/hbb-fullstack/ atau https jika tersedia.
- Emulator Android Studio: http://10.0.2.2/hbb-fullstack/

FITUR V3:
- Pengaturan URL server dari dalam aplikasi tanpa rebuild APK.
- Tombol Tes Koneksi.
- API pendaftaran anggota dan SOS menuju database pusat.
- Website publik/admin tetap menjadi panel pengelolaan.
- Data Android dan website tidak dibuat terpisah.

PENTING:
Backup database horas_bangso_batak sebelum mengganti endpoint. Jangan menghapus database lama.


PEMBARUAN ANDROID v1.1.0:
- Membawa paket website HBB Professional v17 ke folder hbb-fullstack.
- WebView mendukung JavaScript, geolocation, pemilihan/upload file, dan media HTML5.
- Tetap satu server/database pusat; Android tidak membuat database baru.
- Versi aplikasi: 1.1.0.

UNTUK HP FISIK + XAMPP:
1. Sambungkan HP dan laptop ke Wi-Fi/hotspot yang sama.
2. Cari IPv4 laptop dengan ipconfig, misalnya 192.168.1.10.
3. Di aplikasi buka Pengaturan Koneksi Server.
4. Masukkan http://192.168.1.10/hbb-fullstack/ lalu Tes Koneksi dan Simpan.
5. Pastikan Windows Firewall mengizinkan Apache/port 80 dari jaringan lokal.
