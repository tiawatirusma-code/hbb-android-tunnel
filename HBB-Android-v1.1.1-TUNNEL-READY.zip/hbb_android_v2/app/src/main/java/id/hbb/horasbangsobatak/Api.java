package id.hbb.horasbangsobatak;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class Api {
    // Emulator: 10.0.2.2 points to the PC running XAMPP.
    // Physical phone: change this to the PC IPv4, e.g. http://192.168.1.10/hbb-fullstack/
    private static final String PREFS = "hbb_connection";
    private static final String KEY_BASE_URL = "base_url";
    public static final String DEFAULT_BASE_URL = "http://10.0.2.2/hbb-fullstack/";
    public static String baseUrl(Context ctx){
        String u=ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY_BASE_URL,DEFAULT_BASE_URL);
        return normalize(u);
    }
    public static void setBaseUrl(Context ctx,String url){ ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY_BASE_URL,normalize(url)).apply(); }
    private static String normalize(String u){ u=u==null?"":u.trim(); if(!u.endsWith("/"))u+="/"; return u; }
    public static String postMultipart(Context ctx, String path, java.util.Map<String,String> fields, java.util.Map<String,FilePart> files) throws Exception {
        URL url=new URL(baseUrl(ctx)+path); HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setDoOutput(true); c.setRequestMethod("POST");
        String boundary="----HBB"+UUID.randomUUID(); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
        try(DataOutputStream out=new DataOutputStream(c.getOutputStream())){
            for(java.util.Map.Entry<String,String> e:fields.entrySet()){ write(out,"--"+boundary+"\r\nContent-Disposition: form-data; name=\""+e.getKey()+"\"\r\n\r\n"+e.getValue()+"\r\n"); }
            for(java.util.Map.Entry<String,FilePart> e:files.entrySet()){ FilePart f=e.getValue(); write(out,"--"+boundary+"\r\nContent-Disposition: form-data; name=\""+e.getKey()+"\"; filename=\""+f.file.getName()+"\"\r\nContent-Type: "+f.mime+"\r\n\r\n"); try(FileInputStream in=new FileInputStream(f.file)){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);} write(out,"\r\n"); }
            write(out,"--"+boundary+"--\r\n");
        }
        return read(c);
    }
    public static String postForm(Context ctx, String path, java.util.Map<String,String> fields) throws Exception {
        URL url=new URL(baseUrl(ctx)+path); HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setDoOutput(true); c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        StringBuilder s=new StringBuilder(); for(java.util.Map.Entry<String,String> e:fields.entrySet()){if(s.length()>0)s.append('&');s.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8"));}
        try(OutputStream out=c.getOutputStream()){out.write(s.toString().getBytes(StandardCharsets.UTF_8));} return read(c);
    }
    private static void write(OutputStream o,String s)throws IOException{o.write(s.getBytes(StandardCharsets.UTF_8));}
    private static String read(HttpURLConnection c)throws Exception{InputStream in=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(in==null)return "";try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String x;while((x=r.readLine())!=null)s.append(x);return s.toString();}}
    public static final class FilePart { public final File file; public final String mime; public FilePart(File f,String m){file=f;mime=m;} }
    private Api(){}
}
