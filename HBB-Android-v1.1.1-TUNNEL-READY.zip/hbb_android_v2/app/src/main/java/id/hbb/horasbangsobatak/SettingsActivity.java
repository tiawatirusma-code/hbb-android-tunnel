package id.hbb.horasbangsobatak;

import android.app.*;import android.os.*;import android.view.*;import android.widget.*;import java.net.*;

public class SettingsActivity extends Activity {
 EditText url; TextView status;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings); url=findViewById(R.id.serverUrl);status=findViewById(R.id.status);url.setText(Api.baseUrl(this));
  findViewById(R.id.save).setOnClickListener(v->{Api.setBaseUrl(this,url.getText().toString());status.setText("Alamat server tersimpan.");});
  findViewById(R.id.test).setOnClickListener(v->test());
 }
 void test(){Api.setBaseUrl(this,url.getText().toString());status.setText("Menguji koneksi...");new Thread(()->{try{URL u=new URL(Api.baseUrl(this)+"index.php");HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(6000);c.setReadTimeout(6000);c.setRequestMethod("GET");int code=c.getResponseCode();runOnUiThread(()->status.setText(code>=200&&code<400?"✓ Server HBB terhubung (HTTP "+code+")":"Server merespons HTTP "+code));c.disconnect();}catch(Exception e){runOnUiThread(()->status.setText("✗ Tidak terhubung: "+e.getMessage()));}}).start();}
}
