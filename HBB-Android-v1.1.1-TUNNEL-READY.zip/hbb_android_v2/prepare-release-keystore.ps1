$ErrorActionPreference = "Stop"
if (-not (Get-Command keytool -ErrorAction SilentlyContinue)) { throw "JDK belum terpasang." }
$alias = Read-Host "Key alias (contoh: hbb)"
if ([string]::IsNullOrWhiteSpace($alias)) { $alias = "hbb" }
keytool -genkeypair -v -keystore .\hbb-release.jks -alias $alias -keyalg RSA -keysize 4096 -validity 10000 -storetype PKCS12
Write-Host "Keystore selesai dibuat: hbb-release.jks"
Write-Host "Jangan upload ke repository publik."
